 #include "../include/AppGrafo.hpp"

int main() {
    
   AppGrafo* appGrafo = new AppGrafo();
   appGrafo->mostrarMenu();

   return 0;
    
} 
