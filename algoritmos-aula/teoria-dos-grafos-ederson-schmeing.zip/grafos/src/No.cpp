//----------------------CLASSE NO CPP---------------
#include<iostream>
#include "../include/No.hpp"